﻿namespace CVX.WharfDigitalAssistant.Cognitive
{
    public class ResolutionDateRange
    {
        public string timex { get; set; }
        public string type { get; set; }
        public string start { get; set; }
        public string end { get; set; }
        public string value { get; set; }
    }
}
