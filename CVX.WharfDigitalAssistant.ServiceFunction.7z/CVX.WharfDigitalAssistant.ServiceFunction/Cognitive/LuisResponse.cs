﻿using System.Collections.Generic;

namespace CVX.WharfDigitalAssistant.Cognitive
{
    public class LuisResponse
    {
        public string query { get; set; }
        public TopScoringIntent topScoringIntent { get; set; }
        public List<Entity> entities { get; set; }
    }
    public class TopScoringIntent
    {
        public string intent { get; set; }
        public double score { get; set; }
    }
    public class Resolution
    {
        public List<object> values { get; set; }
        public string subtype { get; set; }
        public string value { get; set; }
    }
    public class Entity
    {
        public string entity { get; set; }
        public string type { get; set; }
        public int startIndex { get; set; }
        public int endIndex { get; set; }
        public Resolution resolution { get; set; }
    }
}
