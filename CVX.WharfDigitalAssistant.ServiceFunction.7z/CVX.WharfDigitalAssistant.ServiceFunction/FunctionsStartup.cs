﻿using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Hosting;
using System;
using System.Collections.Generic;
using System.Text;

[assembly: FunctionsStartup(typeof(CVX.WharfDigitalAssistant.ServiceFunction.Startup))]
namespace CVX.WharfDigitalAssistant.ServiceFunction
{
    public abstract class FunctionsStartup : IWebJobsStartup
    {        
        public abstract void Configure(IFunctionsHostBuilder builder);
        
        public abstract void Configure(IWebJobsBuilder builder);
    }
}
