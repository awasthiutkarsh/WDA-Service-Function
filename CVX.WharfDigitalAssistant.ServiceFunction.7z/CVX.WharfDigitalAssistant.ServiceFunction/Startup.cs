﻿using CVX.WharfDigitalAssistant.Strategy;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace CVX.WharfDigitalAssistant.ServiceFunction
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services
                .AddTransientImplementingTypes<IIntentStrategy>()
                .AddTransient<IIntentStrategyFactory, IntentStrategyFactory>();
        }

        public override void Configure(IWebJobsBuilder builder)
        {
            //builder.Services
            //    .AddTransientImplementingTypes<IIntentStrategy>()
            //    .AddTransient<IIntentStrategyFactory, IntentStrategyFactory>();
        }
    }
}
