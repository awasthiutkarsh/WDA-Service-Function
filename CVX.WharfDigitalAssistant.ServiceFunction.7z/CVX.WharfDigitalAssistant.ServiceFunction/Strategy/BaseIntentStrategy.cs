﻿using AdaptiveCards.Templating;
using CVX.WharfDigitalAssistant.Cognitive;
using CVX.WharfDigitalAssistant.DataAccess;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.Luis;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace CVX.WharfDigitalAssistant.Strategy
{
    public abstract class BaseIntentStrategy : IIntentStrategy
    {
        protected readonly ILogger _logger;
        protected readonly IWharfRepository _repo;

        public BaseIntentStrategy(
            ILogger logger,
            IWharfRepository repo)
        {
            _logger = logger;
            _repo = repo;
        }

        public abstract string Key { get; }

        protected static async Task DisplayMessage(
            ITurnContext<IMessageActivity> turnContext, 
            string message, 
            CancellationToken cancellationToken)
        {
            var reply = MessageFactory.Text(message);
            await turnContext.SendActivityAsync(reply, cancellationToken);
        }

        protected async Task DisplayCard(
            ITurnContext<IMessageActivity> turnContext, 
            string cardSchemaFileName, string jsonData, CancellationToken cancellationToken)
        {
            Attachment createCard;
            try
            {
                createCard = CreateAdaptiveCardAttachment(jsonData, cardSchemaFileName);
            }
            catch (System.Exception ex)
            {
                _logger.LogCritical(ex, "Error occurred while creating card");
                throw;
            }
            var reply = MessageFactory.Attachment(createCard);
            await turnContext.SendActivityAsync(reply, cancellationToken);
        }

        private Attachment CreateAdaptiveCardAttachment(string jsonData, string schemaFile)
        {
            string JsonCard = TransformCard(schemaFile, jsonData);

            return new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                //Content = AdaptiveCard.FromJson(JsonCard).Card,
                Content = JsonConvert.DeserializeObject(JsonCard.ToString()),
            };
        }
        private string TransformCard(string template, string payload)
        {
            var templateJson = ReadJsonSchema(template);
            var dataJson = ReadJsonData(payload);
            var transformer = new AdaptiveTransformer();
            var cardJson = transformer.Transform(templateJson.ToString(), dataJson.ToString());
            return cardJson;
        }
        private static JObject ReadJsonSchema(string jsonSchema)
        {
            var path = Path.Combine(".", "JsonSchemas", jsonSchema);
            return JObject.Parse(File.ReadAllText(path));
        }
        private JObject ReadJsonData(string jsonData)
        {
            jsonData = jsonData.Replace("[", "{ \"DataTable\": [");
            jsonData = jsonData.Replace("]", "] }");
            jsonData = jsonData.Replace("null", "\"\"");
            return JObject.Parse(jsonData);
        }
        protected static (bool noDate, string startDate, string endDate) GetDateResolveValue(LuisResponse response)
        {
            JObject dateObj = response.entities?.Where(x => x.type == "builtin.datetimeV2.date").FirstOrDefault()?.resolution?.values?.FirstOrDefault() as JObject;
            JObject dateObjRange = response.entities?.Where(x => x.type == "builtin.datetimeV2.daterange").FirstOrDefault()?.resolution?.values?.FirstOrDefault() as JObject;
            JObject dateObjTimeRange = response.entities?.Where(x => x.type == "builtin.datetimeV2.datetimerange").FirstOrDefault()?.resolution?.values?.FirstOrDefault() as JObject;

            bool noDate = false;
            string mapDate, endDate = "", startDate = "";
            if (dateObj == null & dateObjRange == null & dateObjTimeRange == null)
            {
                noDate = true;
                //setting date to be of yesterday's if not provided in the query
                startDate = DateTime.Today.AddDays(-1).ToString();
            }
            else
            {
                if (dateObj == null)
                {
                    if (dateObjRange == null)
                    {
                        mapDate = dateObjTimeRange.ToString();
                        //setting date to be of yesterday's if not provided in the query
                        var dateResolve = JsonConvert.DeserializeObject<ResolutionDateRange>(mapDate);

                        startDate = dateResolve.start;
                        endDate = dateResolve.end;
                    }
                    else
                    {
                        mapDate = dateObjRange.ToString();
                        //setting date to be of yesterday's if not provided in the query
                        var dateResolve = JsonConvert.DeserializeObject<ResolutionDateRange>(mapDate);

                        startDate = dateResolve.start;
                        endDate = dateResolve.end;
                    }
                }
                else
                {
                    mapDate = dateObj.ToString();
                    //setting date to be of yesterday's if not provided in the query
                    var dateResolve = JsonConvert.DeserializeObject<ResolutionDateRange>(mapDate);

                    startDate = dateResolve.value;
                }
            }

            return (noDate, startDate, endDate);
        }
        protected static string IdentifyNumber(string parmName, InstanceData[] num)
        {
            //string numberOfRecords = recognizerResult.Entities._instance?.number?.FirstOrDefault()?.Text;
            //return num?.Count() > 1 ? num.FirstOrDefault().Text : (num?.Count() > 0 ? (parmName.Contains(num.FirstOrDefault().Text) ? "1" : num.FirstOrDefault().Text) : "1");
            string noOfRecords = "1";
            if (num != null && num.Count() > 0)
            {
                foreach (var item in num)
                {
                    string regexPattern = "\\b" + Convert.ToString(item) + "\\b";
                    if (!Regex.IsMatch(parmName, regexPattern))
                    {
                        noOfRecords = Convert.ToString(item);
                        break;
                    }
                }
            }
            return noOfRecords;
        }

        public abstract Task ProcessIntentAsync(
            LuisModel userIntent, 
            ITurnContext<IMessageActivity> turnContext, 
            CancellationToken cancellationToken);
    }
}
