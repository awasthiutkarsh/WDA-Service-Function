﻿using Microsoft.Extensions.DependencyInjection;

namespace CVX.WharfDigitalAssistant.Strategy
{
    public static class IntentModule
    {
        public static IServiceCollection AddIntentServices(
            this IServiceCollection services)
        {
            return services
                .AddTransientImplementingTypes<IIntentStrategy>()
                .AddTransient<IIntentStrategyFactory, IntentStrategyFactory>();
        }
    }
}
