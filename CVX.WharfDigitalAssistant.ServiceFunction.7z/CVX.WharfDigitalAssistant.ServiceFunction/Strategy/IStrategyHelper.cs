﻿using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using System.Threading;
using System.Threading.Tasks;

namespace CVX.WharfDigitalAssistant.Strategy
{
    public interface IStrategyHelper
    {
        Task DisplayAsync(string intent);

        Task DisplayCardAsync(ITurnContext turnContext, string cardSchemaFileName, string jsonData, CancellationToken cancellationToken);
    }
}
