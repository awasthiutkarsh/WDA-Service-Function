﻿using AdaptiveCards.Templating;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

namespace CVX.WharfDigitalAssistant.Strategy
{
    public class StrategyHelper : IStrategyHelper
    {
        public async Task DisplayAsync(string intent)
        {
            await Task.Delay(100);
            Console.WriteLine($"Display {intent}");
        }
        
        public async Task DisplayCardAsync(ITurnContext turnContext, string cardSchemaFileName, string jsonData, CancellationToken cancellationToken)
        {
            Attachment createCard;
            try
            {
                createCard = CreateAdaptiveCardAttachment(jsonData, cardSchemaFileName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            var reply = MessageFactory.Attachment(createCard);
            await turnContext.SendActivityAsync(reply, cancellationToken);
        }

        private Attachment CreateAdaptiveCardAttachment(string jsonData, string schemaFile)
        {
            string JsonCard = TransformCard(schemaFile, jsonData);

            return new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(JsonCard.ToString()),
            };
        }

        private string TransformCard(string template, string payload)
        {
            var templateJson = ReadJsonSchema(template);
            var dataJson = ReadJsonData(payload);
            var transformer = new AdaptiveTransformer();
            var cardJson = transformer.Transform(templateJson.ToString(), dataJson.ToString());
            return cardJson;
        }

        private static JObject ReadJsonSchema(string jsonSchema)
        {
            var path = Path.Combine(".", "JsonSchemas", jsonSchema);
            return JObject.Parse(File.ReadAllText(path));
        }
        private JObject ReadJsonData(string jsonData)
        {
            jsonData = jsonData.Replace("[", "{ \"DataTable\": [");
            jsonData = jsonData.Replace("]", "] }");
            jsonData = jsonData.Replace("null", "\"\"");
            return JObject.Parse(jsonData);
        }
    }
}
