﻿using CVX.WharfDigitalAssistant.Cognitive;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using System.Threading;
using System.Threading.Tasks;

namespace CVX.WharfDigitalAssistant.Strategy
{
    public interface IIntentStrategy
    {
        string Key { get; }

        Task ProcessIntentAsync(
            LuisModel userIntentResult, 
            ITurnContext<IMessageActivity> turnContext, 
            CancellationToken cancellationToken);
    }
}
