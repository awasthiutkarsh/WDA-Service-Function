﻿using CVX.WharfDigitalAssistant.Cognitive;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CVX.WharfDigitalAssistant.Strategy
{
    public class IntentStrategyFactory : IIntentStrategyFactory
    {
        private readonly IDictionary<string, IIntentStrategy> _intentStrategies;

        public IntentStrategyFactory(
            IEnumerable<IIntentStrategy> intentStrategies)
        {
            _intentStrategies = intentStrategies.ToDictionary(
                x => x.Key);
        }

        public IIntentStrategy GetStrategy(LuisModel userIntent)
        {
            if (_intentStrategies.TryGetValue(
                    userIntent.TopIntent().intent.ToString()?.Replace("_", string.Empty),
                    out var Strategy))
            {
                return Strategy;
            }

            throw new ArgumentException(
                $"The Intent {userIntent.TopIntent().intent} is not handled",
                nameof(userIntent));
        }
    }
}
