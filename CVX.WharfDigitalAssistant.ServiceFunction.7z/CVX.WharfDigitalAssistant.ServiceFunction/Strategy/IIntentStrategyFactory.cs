﻿using CVX.WharfDigitalAssistant.Cognitive;

namespace CVX.WharfDigitalAssistant.Strategy
{
    public interface IIntentStrategyFactory
    {
        IIntentStrategy GetStrategy(LuisModel userIntent);
    }
}
