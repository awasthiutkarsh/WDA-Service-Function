﻿using CVX.WharfDigitalAssistant.Cognitive;
using CVX.WharfDigitalAssistant.DataAccess;
using CVX.WharfDigitalAssistant.Strategy;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CVX.WharfDigitalAssistant.Intents
{
    public class WharfStatusCurrent : BaseIntentStrategy
    {
        public WharfStatusCurrent(
            ILogger<WharfStatusCurrent> logger,
            IWharfRepository repo)
            : base(logger, repo) {}

        public override string Key => GetType().Name;

        private string cardSchemaFileName => $"{Key}-schema.json";

        public override async Task ProcessIntentAsync(
            LuisModel recognizerResult,
            ITurnContext<IMessageActivity> turnContext,
            CancellationToken cancellationToken)
        {
            //Call Database by passing the parameters
            var data = await _repo.GetWharfStatusCurrentAsync();

            string message;

            //Display Card
            if (data.Count > 0)
            {
                string jsonData = JsonConvert.SerializeObject(data);
                await DisplayCard(turnContext, cardSchemaFileName, jsonData, cancellationToken);
            }
            else
            {
                _logger.LogInformation("No data returned for wharf");

                message = "Sorry there was no activity at the wharf today.";
                await DisplayMessage(turnContext, message, cancellationToken);
            }
        }
    }
}
