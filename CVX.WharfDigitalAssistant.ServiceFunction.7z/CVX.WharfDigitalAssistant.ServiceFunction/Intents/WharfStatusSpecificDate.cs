﻿using CVX.WharfDigitalAssistant.Cognitive;
using CVX.WharfDigitalAssistant.DataAccess;
using CVX.WharfDigitalAssistant.Strategy;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace CVX.WharfDigitalAssistant.Intents
{
    public class WharfStatusSpecificDate : BaseIntentStrategy
    {
        public WharfStatusSpecificDate(
            ILogger<WharfStatusSpecificDate> logger,
            IWharfRepository repo)
            : base(logger, repo) {}

        public override string Key => GetType().Name;

        private string cardSchemaFileName => $"{Key}-schema.json";

        public override async Task ProcessIntentAsync(
            LuisModel recognizerResult,
            ITurnContext<IMessageActivity> turnContext,
            CancellationToken cancellationToken)
        {
            var obj = recognizerResult.Properties["luisResult"] as JObject;
            var response = JsonConvert.DeserializeObject<LuisResponse>(obj.ToString());

            string message, startDate;

            startDate = GetDateResolveValue(response).startDate;
            _logger.LogInformation($"Identified parameter(s) from entity are, start date: {startDate}");

            //Call Database by passing the parameters
            var data = await _repo.GetWharfStatusSpecificDateAsync(startDate);



            //Display Card
            if (data.Count > 0)
            {
                string jsonData = JsonConvert.SerializeObject(data);
                await DisplayCard(turnContext, cardSchemaFileName, jsonData, cancellationToken);
            }
            else
            {
                _logger.LogInformation($"No data available for start date {startDate}");

                message = $"Sorry there was no activity at the wharf on {startDate}";
                await DisplayMessage(turnContext, message, cancellationToken);
            }
        }
    }
}
