﻿using System.IO;
using System.Reflection;

namespace CVX.WharfDigitalAssistant.DataAccess
{
    public static class DataHelper
    {
        public static string GetDataScriptFromFile(string fileName)
        {
            var assemblyPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            var path = Path.Combine(assemblyPath, "DataScripts", fileName);
            var content = File.ReadAllText(path);

            return content;
        }
    }
}