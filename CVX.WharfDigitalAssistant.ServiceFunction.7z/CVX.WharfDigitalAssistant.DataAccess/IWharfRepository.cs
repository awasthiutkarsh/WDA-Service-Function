﻿using CVX.WharfDigitalAssistant.DataAccess.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CVX.WharfDigitalAssistant.DataAccess
{
    public interface IWharfRepository
    {

        Task<List<WharfStatusCurrentDataRows>> GetWharfStatusCurrentAsync();

        Task<List<WharfStatusSpecificDateDataRows>> GetWharfStatusSpecificDateAsync(string wharfStatusDate);
    }
}