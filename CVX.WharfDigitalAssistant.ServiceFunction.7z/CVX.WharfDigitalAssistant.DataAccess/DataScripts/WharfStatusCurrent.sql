Declare @startTENDERED As DATE
SET @startTENDERED = '2014-01-01';
with q1 as (
	select wo.ORDERID,wo.ORDER_,wo.STARTTIME ,WO.ENDTIME,WO.TENDERED, 
	OSeq20.StartTime AS MOOR_STARTTIME
	,OSeq80.FinishTime AS UNMOOR_FINISHTIME
	,OSeq50.StartTime AS DISCHARGECARGO_STARTTIME
	,OSeq50.FinishTime AS DISCHARGECARGO_FINISHTIME
	,OSeq56.StartTime AS LOADCARGO_STARTTIME
	,OSeq56.FinishTime AS LOADCARGO_FINISHTIME
	,d.BERTH
	,c.MASTERCODE
	from [dbo].[FULL_W_ORDER] wo
	inner join [dbo].[FULL_W_VESSEL] b
	on wo.ORDERID = b.ORDERID
	inner join dbo.MASTER c
	on c.MASTERID = b.VESSELID 
	inner join dbo.W_BERTHINFO d
	on b.BERTHID=d.BERTHID
	LEFT JOIN dbo.FULL_W_OPSEQ OSeq20(NOLOCK)
	ON OSeq20.ORDERID = WO.ORDERID
	AND OSeq20.OPSEQID = 20
	LEFT JOIN dbo.FULL_W_OPSEQ OSeq80(NOLOCK)
	ON OSeq80.ORDERID = WO.ORDERID
	AND OSeq80.OPSEQID = 80
	LEFT JOIN dbo.FULL_W_OPSEQ OSeq30(NOLOCK)
	ON OSeq30.ORDERID = WO.ORDERID
	AND OSeq30.OPSEQID = 30
	LEFT JOIN dbo.FULL_W_OPSEQ OSeq40(NOLOCK)
	ON OSeq40.ORDERID = WO.ORDERID
	AND OSeq40.OPSEQID = 40
	LEFT JOIN dbo.FULL_W_OPSEQ OSeq50(NOLOCK)
	ON OSeq50.ORDERID = WO.ORDERID
	AND OSeq50.OPSEQID = 50
	LEFT JOIN dbo.FULL_W_OPSEQ OSeq56(NOLOCK)
	ON OSeq56.ORDERID = WO.ORDERID
	AND OSeq56.OPSEQID = 56
	WHERE WO.TENDERED > @startTENDERED	
),
CTE2 
AS
(
SELECT q1.order_ as Nomination,
q1.berth, q1.MASTERCODE as vessel,
q1.starttime,q1.endtime,MOOR_STARTTIME,UNMOOR_FINISHTIME,TENDERED,
									 
case when (Tendered Is Not Null) And  (MOOR_STARTTIME Is Null) And (UNMOOR_FINISHTIME Is Null) 
	then 'Nor Tendered' 
	when  (Tendered Is Not Null) And  (MOOR_STARTTIME Is Not Null) And (convert(datetime,DischargeCargo_StartTime) Is Null) And (LOADCARGO_STARTTIME Is Null) 
	then 'Vessel Moored' 
	when (convert(datetime,DISCHARGECARGO_STARTTIME) Is Not Null) And (convert(datetime,DISCHARGECARGO_FINISHTIME) Is Null) 
	then 'Vessel Discharging' 
	when (convert(datetime,DischargeCargo_StartTime) Is Not Null) And (cast(DateDiff(SECOND,convert(datetime,DISCHARGECARGO_FINISHTIME),CURRENT_TIMESTAMP)/ 3600.0  as decimal(10,2))<5) And (UNMOOR_FINISHTIME Is Null) 
	then 'Discharge Complete' 
	when (LOADCARGO_STARTTIME Is Not Null) and (LOADCARGO_FINISHTIME Is Null) 
	then 'Vessel Loading' 
	when (LOADCARGO_STARTTIME Is Not Null) and (LOADCARGO_FINISHTIME Is Not Null) And (cast(DateDiff(SECOND,LOADCARGO_FINISHTIME,CURRENT_TIMESTAMP)/ 3600.0  as decimal(10,2))<5) And (UNMOOR_FINISHTIME Is Null) 
	then 'Loading Complete' 
	when Cast(DateDiff(second,UNMOOR_FINISHTIME,CURRENT_TIMESTAMP)/ 3600.0  as decimal(10,2)) <1 
	then 'Vessel Sailed Last 24 Hours' 
							
	else 'Vessel Sailed' 
end [status],
CASE WHEN ISNULL(convert(datetime,DISCHARGECARGO_FINISHTIME),'2000-01-01') > ISNULL(LOADCARGO_FINISHTIME ,'2000-01-01') THEN convert(datetime,DISCHARGECARGO_FINISHTIME) ELSE LOADCARGO_FINISHTIME  END  AS [Cargo Handling End Time]
															 
from q1
),
CTE3
AS
(
Select *,
case  
	when (MOOR_STARTTIME Is Null) and (UNMOOR_FINISHTIME Is Not Null) then 'Y' 
	when (UNMOOR_FINISHTIME is Null) and (DateDiff(day,[Cargo Handling End Time],GetDate())>5) then 'Y'
	when(TENDERED is Not Null) and(DateDiff(day, TENDERED, GetDate()) > 90) then 'Y'
	when(UNMOOR_FINISHTIME is Null) and(DateDiff(day, MOOR_STARTTIME, GetDate()) > 30) then 'Y'
	when(UNMOOR_FINISHTIME is not null) and([Cargo Handling End Time] is null) then 'Y'
	when(TENDERED is not null) and(MOOR_STARTTIME is null) and(UNMOOR_FINISHTIME is null) then 'N'
	else 'N'
end AS[Error Check]
						
from CTE2
)
SELECT
Nomination, Berth, Vessel,Moor_StartTime as [StartTime],[Status]
--, CASE WHEN[Error Check] = 'N' AND(UNMOOR_FINISHTIME Is Null) AND(TENDERED is not null) AND(MOOR_STARTTIME Is Not Null)  THEN 'Y' ELSE 'N' END AS[AtBerth]

FROM CTE3
WHERE CASE WHEN[Error Check]='N' AND(UNMOOR_FINISHTIME Is Null) AND(TENDERED is not null) AND(MOOR_STARTTIME Is Not Null)  THEN 'Y' ELSE 'N' END ='Y'
AND [Status] != 'Vessel Sailed';