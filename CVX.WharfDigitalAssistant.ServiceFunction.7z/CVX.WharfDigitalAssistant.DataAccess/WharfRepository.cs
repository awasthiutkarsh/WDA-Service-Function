﻿using CVX.WharfDigitalAssistant.DataAccess.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CVX.WharfDigitalAssistant.DataAccess
{
    public class WharfRepository : IWharfRepository
    {
        private readonly IConfiguration _config;
        private readonly ILogger _logger;

        public WharfRepository(IConfiguration config, ILoggerFactory logger)
        {
            _config = config;
            _logger = logger.CreateLogger("WharfRepository");
        }

        public async Task<List<WharfStatusCurrentDataRows>> GetWharfStatusCurrentAsync()
        {
            string sql = DataHelper.GetDataScriptFromFile("WharfStatusCurrent.sql");

            using (var connection = new SqlConnection(_config["ConnectionStrings:Wharf"]))
            {
                var CurrentStatus = await connection.QueryAsync<WharfStatusCurrentDataRows>(sql);
                return CurrentStatus.ToList();
            }
        }

        public async Task<List<WharfStatusSpecificDateDataRows>> GetWharfStatusSpecificDateAsync(string wharfStatusDate)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@wharfStatusAtDate", wharfStatusDate);
            string sql = DataHelper.GetDataScriptFromFile("WharfStatusSpecificDate.sql");

            using (var connection = new SqlConnection(_config["ConnectionStrings:Wharf"]))
            {
                var CurrentStatus = await connection.QueryAsync<WharfStatusSpecificDateDataRows>(sql, parameters);

                return CurrentStatus.ToList();
            }
        }
    }
}