﻿namespace CVX.WharfDigitalAssistant.Bot.DAL
{
    public class ConnectionStrings
    {
        public string Azure { get; set; }
        public string Wharf { get; set; }
        public string Teradata { get; set; }
        public string SpotFire { get; set; }
    }
}