﻿namespace CVX.WharfDigitalAssistant.DataAccess.Models
{
    public class WharfStatusSpecificDateDataRows
    {
        public string Nomination { get; set; }
        public string Berth { get; set; }
        public string Vessel { get; set; }
        public string StartTime { get; set; }
        public string Status { get; set; }
    }
}
